<template>
    <div>
      <h1>Bienvenido a la sección de usuarios</h1>
    </div>
  </template>
  
  <script>
  export default {
    name: 'Usuarios'
  }
  </script>
  