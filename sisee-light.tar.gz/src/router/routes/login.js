export default [
    {
      path: '/login',
      name: 'Login',
      component: () => import('@/views/Login.vue'),
    }
  ]
  