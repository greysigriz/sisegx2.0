import sistemaClasificacionDependencias from '../assets/dependencias_cancun.json';

export const sistemaClasificacion = {
  sistema_clasificacion_dependencias: sistemaClasificacionDependencias.sistema_clasificacion_dependencias
};
