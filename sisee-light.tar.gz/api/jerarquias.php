<?php
//C:\xampp\htdocs\SISEE\api\jerarquias.php
require_once __DIR__ . '/cors.php';
require_once __DIR__ . '/../config/database.php';

// Instanciar base de datos
$database = new Database();
$db = $database->getConnection();

// Obtener método de solicitud
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    // Consulta para obtener todas las jerarquías de usuarios
    $query = "SELECT ju.Id, ju.IdUsuarioSuperior, ju.IdUsuarioSubordinado,
              CONCAT(u1.Nombre, ' ', u1.ApellidoP) as NombreUsuarioSuperior,
              CONCAT(u2.Nombre, ' ', u2.ApellidoP) as NombreUsuarioSubordinado,
              u1.Usuario as UsuarioSuperior,
              u2.Usuario as UsuarioSubordinado
              FROM JerarquiaUsuario ju
              JOIN Usuario u1 ON ju.IdUsuarioSuperior = u1.Id
              JOIN Usuario u2 ON ju.IdUsuarioSubordinado = u2.Id
              ORDER BY u1.Nombre, u2.Nombre";

    $stmt = $db->prepare($query);
    $stmt->execute();
    $num = $stmt->rowCount();

    $jerarquias_arr = array();
    $jerarquias_arr["records"] = array();

    if ($num > 0) {
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            extract($row);

            $jerarquia_item = array(
                "Id" => $Id,
                "IdUsuarioSuperior" => $IdUsuarioSuperior,
                "IdUsuarioSubordinado" => $IdUsuarioSubordinado,
                "NombreUsuarioSuperior" => $NombreUsuarioSuperior,
                "NombreUsuarioSubordinado" => $NombreUsuarioSubordinado,
                "UsuarioSuperior" => $UsuarioSuperior,
                "UsuarioSubordinado" => $UsuarioSubordinado
            );

            array_push($jerarquias_arr["records"], $jerarquia_item);
        }
    }

    http_response_code(200);
    echo json_encode($jerarquias_arr);
}
elseif ($method === 'POST') {
    // Recibir los datos enviados
    $data = json_decode(file_get_contents("php://input"));

    if(!empty($data->usuarioId)) {
        try {
            // Comenzar transacción
            $db->beginTransaction();

            // 1. Eliminar todas las relaciones existentes donde el usuario es superior
            $query = "DELETE FROM JerarquiaUsuario WHERE IdUsuarioSuperior = :usuarioId";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':usuarioId', $data->usuarioId);
            $stmt->execute();

            // 2. Eliminar todas las relaciones existentes donde el usuario es subordinado
            $query = "DELETE FROM JerarquiaUsuario WHERE IdUsuarioSubordinado = :usuarioId";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':usuarioId', $data->usuarioId);
            $stmt->execute();

            // 3. Insertar nuevas relaciones donde el usuario es superior
            if (!empty($data->subordinados) && is_array($data->subordinados)) {
                $query = "INSERT INTO JerarquiaUsuario (IdUsuarioSuperior, IdUsuarioSubordinado) VALUES (:usuarioId, :subordinadoId)";
                $stmt = $db->prepare($query);

                foreach ($data->subordinados as $subordinadoId) {
                    $stmt->bindParam(':usuarioId', $data->usuarioId);
                    $stmt->bindParam(':subordinadoId', $subordinadoId);
                    $stmt->execute();
                }
            }

            // 4. Insertar nuevas relaciones donde el usuario es subordinado
            if (!empty($data->superiores) && is_array($data->superiores)) {
                $query = "INSERT INTO JerarquiaUsuario (IdUsuarioSuperior, IdUsuarioSubordinado) VALUES (:superiorId, :usuarioId)";
                $stmt = $db->prepare($query);

                foreach ($data->superiores as $superiorId) {
                    $stmt->bindParam(':superiorId', $superiorId);
                    $stmt->bindParam(':usuarioId', $data->usuarioId);
                    $stmt->execute();
                }
            }

            // Confirmar transacción
            $db->commit();

            http_response_code(200);
            echo json_encode(array("message" => "Jerarquías actualizadas con éxito."));
        }
        catch (Exception $e) {
            // Revertir cambios en caso de error
            $db->rollBack();

            http_response_code(500);
            echo json_encode(array("message" => "Error al actualizar jerarquías: " . $e->getMessage()));
        }
    }
    else {
        http_response_code(400);
        echo json_encode(array("message" => "Datos incompletos."));
    }
}
else {
    http_response_code(405);
    echo json_encode(array("message" => "Método no permitido."));
}
?>
